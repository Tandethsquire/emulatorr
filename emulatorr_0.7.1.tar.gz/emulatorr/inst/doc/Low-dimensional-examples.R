## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(emulatorr)
library(lhs)
library(ggplot2)
set.seed(125)

## -----------------------------------------------------------------------------
func <- function(x) {
  2*x + 3*x*sin(5*pi*(x-0.1)/0.4)
}

## -----------------------------------------------------------------------------
data1d <- data.frame(x = seq(0.05, 0.5, by = 0.05), f = func(seq(0.05, 0.5, by = 0.05)))

## -----------------------------------------------------------------------------
ranges1d <- list(x = c(0, 0.6))
pre_em1d <- emulator_from_data(data1d, c('f'), ranges1d, deltas = 0)
print(pre_em1d)

## -----------------------------------------------------------------------------
pre_em1d[[1]]$active_vars <- c(TRUE)

## -----------------------------------------------------------------------------
t_em1d <- pre_em1d[[1]]$adjust(data1d, 'f')

## -----------------------------------------------------------------------------
t_em1d$get_cov(data1d)
t_em1d$get_exp(data1d) - data1d$f

## -----------------------------------------------------------------------------
test_points <- data.frame(x = seq(0, 0.6, by = 0.001))
em_exp <- t_em1d$get_exp(test_points)
em_var <- t_em1d$get_cov(test_points)

## -----------------------------------------------------------------------------
plotting1d <- data.frame(
  x = test_points$x,
  f = func(test_points$x),
  E = em_exp,
  max = em_exp + 3*sqrt(em_var),
  min = em_exp - 3*sqrt(em_var)
)

## ----fig.width = 7, fig.height = 7--------------------------------------------
plot(data = plotting1d, f ~ x, ylim = c(min(plotting1d[,-1]), max(plotting1d[,-1])),
     type = 'l', main = "Emulation of a Simple 1-dimensional Function", xlab = "Parameter value", ylab = "Function value")
lines(data = plotting1d, E ~ x, col = 'blue')
lines(data = plotting1d, min ~ x, col = 'red', lty = 2)
lines(data = plotting1d, max ~ x, col = 'red', lty = 2)
points(data = data1d, f ~ x, pch = 16, cex = 1)
legend('bottomleft', inset = c(0.05, 0.05), legend = c("Function value", "Emulated value", "Uncertainty Bounds"),
       col = c('black', 'blue', 'red'), lty = c(1,1,2))

## -----------------------------------------------------------------------------
target1d <- list(f = list(val = 0, sigma = 0.05))

## -----------------------------------------------------------------------------
new_points1d <- generate_new_runs(list(t_em1d), ranges1d, 10, target1d, method = 'lhs', include_line - FALSE)

## ----fig.width = 7, fig.height = 7--------------------------------------------
plot(data = plotting1d, f ~ x, ylim = c(min(plotting1d[,-1]), max(plotting1d[,-1])),
     type = 'l', main = "Emulation of a Simple 1-dimensional Function", xlab = "Parameter value", ylab = "Function value")
lines(data = plotting1d, E ~ x, col = 'blue')
lines(data = plotting1d, min ~ x, col = 'red', lty = 2)
lines(data = plotting1d, max ~ x, col = 'red', lty = 2)
points(data = data1d, f ~ x, pch = 16, cex = 1)
legend('bottomleft', inset = c(0.05, 0.05), legend = c("Function value", "Emulated value", "Uncertainty Bounds"),
       col = c('black', 'blue', 'red'), lty = c(1,1,2))
abline(h = target1d$f$val, lty = 2)
abline(h = target1d$f$val + 3*target1d$f$sigma, lty = 2)
abline(h = target1d$f$val - 3*target1d$f$sigma, lty = 2)
points(x = unlist(new_points1d, use.names = F), y = func(unlist(new_points1d, use.names = F)), pch = 16, col = 'blue')

## ----fig.width = 7, fig.height = 7--------------------------------------------
new_data1d <- data.frame(x = unlist(new_points1d, use.names = F), f = func(unlist(new_points1d, use.names = F)))

em1d_2 <- emulator_from_data(new_data1d, c('f'), ranges1d, deltas = 0)
em1d_2[[1]]$active_vars = c(TRUE)

t_em1d_2 <- purrr::map(seq_along(em1d_2), ~em1d_2[[.]]$adjust(new_data1d, 'f'))

em1d_2_results <- data.frame(E = t_em1d_2[[1]]$get_exp(test_points), V = t_em1d_2[[1]]$get_cov(test_points))
plotting1d2 <- data.frame(x = plotting1d$x, f = plotting1d$f, E = em1d_2_results$E,
                          max = em1d_2_results$E + 3*sqrt(em1d_2_results$V),
                          min = em1d_2_results$E - 3*sqrt(em1d_2_results$V))
plot(data = plotting1d2, f ~ x, ylim = c(min(plotting1d2[,-1]), max(plotting1d2[,-1])),
     type = 'l', main = "Emulator of a Simple 1-dimensional Function: Wave 2", xlab = "Parameter value", ylab = "Function value")
lines(data = plotting1d2, E ~ x, col = 'blue')
lines(data = plotting1d2, max ~ x, col = 'red', lty = 2)
lines(data = plotting1d2, min ~ x, col = 'red', lty = 2)
points(data = new_data1d, f ~ x, pch = 16, cex = 1)
legend('topleft', inset = c(0.05, 0.05), legend = c("Function value", "Emulated value", "Uncertainty Bounds"), col = c('black', 'blue', 'red'), lty = c(1,1,2))


## ---- fig.width = 7, fig.height = 7-------------------------------------------
new_new_points1d <- generate_new_runs(c(t_em1d_2, t_em1d), ranges1d, 10, z = c(target1d, target1d), method = 'lhs', include_line = F)

plot(data = plotting1d2, f ~ x, ylim = c(min(plotting1d2[,-1]), max(plotting1d2[,-1])),
     type = 'l', main = "Emulator of a Simple 1-dimensional Function: Wave 2", xlab = "Parameter value", ylab = "Function value")
lines(data = plotting1d2, E ~ x, col = 'blue')
lines(data = plotting1d2, max ~ x, col = 'red', lty = 2)
lines(data = plotting1d2, min ~ x, col = 'red', lty = 2)
points(data = new_data1d, f ~ x, pch = 16, cex = 1)
legend('topleft', inset = c(0.05, 0.05), legend = c("Function value", "Emulated value (wave 2)", "Uncertainty Bounds"), col = c('black', 'blue', 'red'), lty = c(1,1,2))
abline(h = target1d$f$val, lty = 2)
abline(h = target1d$f$val + 3*target1d$f$sigma, lty = 2)
abline(h = target1d$f$val - 3*target1d$f$sigma, lty = 2)
points(x = unlist(new_new_points1d, use.names = F), y = func(unlist(new_new_points1d, use.names = F)), pch = 16, col = 'blue')

## -----------------------------------------------------------------------------
func1 <- function(x) {
  2*cos(1.2*x[[1]]-2) + 3*sin(-0.8*x[[2]]+1)
}
func2 <- function(x) {
  x[[2]]*sin(x[[1]]) - 3*cos(x[[1]]*x[[2]])
}
initial_data <- setNames(data.frame(sweep(maximinLHS(20, 2) - 1/2, 2, c(pi, 2), "*")), c('x', 'y'))
validation_data <- setNames(data.frame(sweep(maximinLHS(20, 2) - 1/2, 2, c(pi, 2), "*")), c('x', 'y'))
initial_data$f1 <- apply(initial_data, 1, func1)
initial_data$f2 <- apply(initial_data, 1, func2)
validation_data$f1 <- apply(validation_data, 1, func1)
validation_data$f2 <- apply(validation_data, 1, func2)

## -----------------------------------------------------------------------------
ranges2d <- list(
  x = c(-pi, pi),
  y = c(-1, 1)
)
targets2d <- list(
  f1 = list(val = func1(c(0.1, -0.4)), sigma = 0.1),
  f2 = list(val = func2(c(0.1, -0.4)), sigma = 0.005)
)

## -----------------------------------------------------------------------------
ems2d <- emulator_from_data(initial_data, c('f1','f2'), ranges2d)
t_ems2d <- purrr::map(seq_along(ems2d), ~ems2d[[.]]$adjust(initial_data, c('f1','f2')[[.]]), lik.method = 'my')
ems2d

## ---- fig.width = 7, fig.height = 7-------------------------------------------
invalid_points <- validation_diagnostics(t_ems2d, validation_data, c('f1','f2'), targets = targets2d)

## ----fig.width = 7, fig.height = 7--------------------------------------------
inflated_em <- t_ems2d[[2]]$set_sigma(t_ems2d[[2]]$u_sigma*2)
validation_diagnostics(list(t_ems2d[[1]], inflated_em), validation_data, c('f1','f2'), targets = targets2d)

## ----fig.width = 7, fig.height = 7--------------------------------------------
emulator_plot(t_ems2d)
emulator_plot(t_ems2d, var_name = 'sd')
emulator_plot(t_ems2d, var_name = 'imp', targets = targets2d)
emulator_plot(t_ems2d, var_name = 'maximp', targets = targets2d)

## ----fig.width = 7, fig.height = 7--------------------------------------------
new_points2d <- generate_new_runs(t_ems2d, ranges2d, 40, z = targets2d)
new_data2d <- data.frame(x = new_points2d$x, y = new_points2d$y, f1 = apply(new_points2d, 1, func1), f2 = apply(new_points2d, 1, func2))
plot(new_data2d[,c('x','y')], pch = 16, cex = 0.5)

## -----------------------------------------------------------------------------
sampled <- sample(40, 20)
train2d <- new_data2d[sampled,]
valid2d <- new_data2d[!seq_along(new_data2d[,1])%in%sampled,]

## -----------------------------------------------------------------------------
second_wave2d <- emulator_from_data(train2d, c('f1','f2'), ranges2d, lik.method = 'my')
second_wave2d
second_tems2d <- purrr::map(seq_along(second_wave2d), ~second_wave2d[[.]]$adjust(train2d, c('f1','f2')[[.]]))

## ----fig.width = 7, fig.height = 7--------------------------------------------
invalid_points <- validation_diagnostics(second_tems2d, valid2d, c('f1','f2'), targets = targets2d)

## ----fig.width = 7, fig.height = 7--------------------------------------------
emulator_plot(second_tems2d, 'maximp', targets = targets2d)
emulator_plot(c(t_ems2d, second_tems2d), 'maximp', targets = c(targets2d, targets2d))

## ----fig.width = 7, fig.height = 7--------------------------------------------
new_points2d2 <- generate_new_runs(c(second_tems2d, t_ems2d), ranges2d, 40, z = c(targets2d, targets2d))
plot(new_points2d2, pch = 16, cex = 0.5)

## -----------------------------------------------------------------------------
new_new_data2d <- data.frame(x = new_points2d2$x, y = new_points2d2$y, f1 = apply(new_points2d2, 1, func1), f2 = apply(new_points2d2, 1, func2))

## ----fig.width = 7, fig.height = 7--------------------------------------------
wave_data_list <- list(rbind(initial_data, validation_data), new_data2d, new_new_data2d)
simulator_plot(wave_data_list, z = targets2d)
my_palette <- c('black', 'blue', 'red')
simulator_plot(wave_data_list, z = targets2d, wave_numbers = 1:2, palette = my_palette)

## ----fig.width = 7, fig.height = 7--------------------------------------------
initial_LHS <- setNames(data.frame(sweep(maximinLHS(40, 2) - 1/2, 2, c(pi, 2), "*")), c('x', 'y'))
new_points_IDEMC <- IDEMC(initial_LHS, c(second_tems2d, t_ems2d), c(targets2d, targets2d), s = 200, sn = 400, p = 0.3, imp = 3)

## ----fig.width = 7, fig.height = 7--------------------------------------------
plot(do.call('rbind', new_points_IDEMC), pch = 16, cex = 0.5, col = c(rep('black', nrow(new_points_IDEMC[[1]])), rep('blue', nrow(new_points_IDEMC[[2]])), rep('yellow', nrow(new_points_IDEMC[[3]])), rep('green', nrow(new_points_IDEMC[[4]]))))

